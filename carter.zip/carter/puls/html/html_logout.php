<html>
<head>
	<title>Logging Out</title>
	<link rel="stylesheet" href="puls.css" type="text/css" />
</head>
<body>
	<h1>Logged Out</h1>
	You have successfully <b>logged out</b>. Back to <a href="index.php">index</a>.
</body>
</html>