<?php

if (!$refresh) $refresh = "index.php";

?>
<html>
<head>
	<title>Rerdirect</title>
	<meta http-equiv="refresh" content="0;url=<?php print $refresh; ?>" />
</head>
<body>
</body>
</html>