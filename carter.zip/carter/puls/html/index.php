<?php

// This should eventually redirect to the homepage

?>